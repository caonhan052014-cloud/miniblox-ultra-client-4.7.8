(() => {
  // CrazyGames embeds the game in one or more iframes. Keep the UI in the top
  // page only, otherwise each frame injects duplicate prompts and panels.
  if (window.top !== window.self) {
    if (!window.__mbucFrameKeyRelay) {
      window.__mbucFrameKeyRelay = true;
      window.addEventListener('keydown', e => {
        if (((e.key && e.key.toLowerCase() === 'h') || e.code === 'KeyH') && !e.repeat &&
            !['INPUT','TEXTAREA'].includes(document.activeElement?.tagName) &&
            !document.activeElement?.isContentEditable) {
          window.top.postMessage({ type: 'MBUC_TOGGLE_CLIENT' }, '*');
        }
      }, true);
    }
    return;
  }
  if (window.__miniBloxUltra16Loaded) return;
  window.__miniBloxUltra16Loaded = true;

  let fps = 0;
  const clicks = [];
  // Measure animation-frame callbacks in the page's MAIN world, not this isolated extension world.
  const fpsHook = document.createElement('script');
  fpsHook.src = chrome.runtime.getURL('fps-hook.js');
  fpsHook.async = false;
  (document.documentElement || document.head).appendChild(fpsHook);
  fpsHook.remove();
  window.addEventListener('message', event => {
    if (event.source !== window || !event.data || event.data.type !== 'MBUC_FPS_METRIC') return;
    const value = Number(event.data.fps);
    if (Number.isFinite(value) && value >= 0 && value <= 1000) fps = Math.round(value);
  });
  window.addEventListener('click', () => { const now = Date.now(); clicks.push(now); while (clicks.length && now - clicks[0] > 1000) clicks.shift(); }, true);

  function build() {
    if (!document.body || document.getElementById('mbuc-panel')) return;
    const panel = document.createElement('div');
    panel.id = 'mbuc-panel';
    panel.classList.add('mbuc-hidden');
    panel.innerHTML = `
      <header id="mbuc-titlebar">
        <div class="mbuc-brand"><span class="mbuc-bolt">ϟ</span><div><strong>MiniBlox Ultra Client</strong><small>Vietnam Red × Gold Edition · v4.7.1</small></div></div>
        <div class="mbuc-head-actions"><span class="mbuc-key">H</span><button id="mbuc-min" title="Thu nhỏ">—</button><button id="mbuc-close" title="Đóng">×</button></div>
      </header>
      <nav class="mbuc-tabs"><button class="active" data-tab="home">Home</button><button data-tab="modules">Modules</button><button data-tab="settings">Settings</button><button data-tab="translation">Translation Layer</button></nav>
      <main>
        <section id="mbuc-home" class="mbuc-page">
          <div class="mbuc-stats"><div class="mbuc-stat"><span>FPS</span><b id="mbuc-fps">--</b></div><div class="mbuc-stat"><span>CPS</span><b id="mbuc-cps">0</b></div></div>
          <div class="mbuc-card"><h3>Hiệu năng</h3><label><input type="checkbox" id="mbuc-motion"> Giảm chuyển động của bảng</label><label><input type="checkbox" id="mbuc-low-fps"> Chế độ nhẹ (giảm cập nhật HUD)</label><p class="mbuc-note">Chế độ nhẹ giảm cập nhật tiện ích, không giới hạn FPS của game.</p></div>
          <div class="mbuc-tip">Nhấn <b>H</b> để mở/đóng. Bảng cố định ở giữa màn hình.</div>
        </section>
        <section id="mbuc-modules" class="mbuc-page" hidden>
          <div class="mbuc-module-window">
            <div class="mbuc-module-window-head"><div><h3>Modules</h3><p>Danh sách tính năng</p></div><button id="mbuc-modules-close" title="Đóng Modules">×</button></div>
            <div class="mbuc-module-grid">
              ${[['ReadHoChiMinh','Hack'],['Fullbright','Visual'],['Dynamic Crosshair','Visual'],['Crosshair Editor','Visual'],['Zoom','Visual'],['No Weather','Visual'],['Texture Pack Manager','Visual'],['PvP HUD','HUD'],['Keystrokes HUD','HUD'],['Clock HUD','HUD'],['FPS HUD','HUD'],['CPS HUD','HUD'],['TextGUI','HUD'],['VietNam HUD','HUD'],['Theme & Profile','UI'],['Player Hearts NameTag','HUD']].map(([n,c])=>`<label class="mbuc-module"><span><small>${c}</small><b>${n}</b></span><input type="checkbox" data-module="${n}"><i></i></label>`).join('')}
            </div>
            <section class="mbuc-skin-tools" aria-label="Custom Skin and Cape">
              <h3>Custom Skin / Cape</h3>
              <p>Đổi texture skin hoặc cape của các tên có sẵn trên miniblox.io. URL ảnh riêng phải là HTTPS trực tiếp tới ảnh.</p>
              <label>Loại texture<select id="mbuc-skin-mode"><option value="skin">Skin</option><option value="cape">Cape</option></select></label>
              <label>Tên skin / cape<select id="mbuc-skin-name"></select></label>
              <label>URL ảnh riêng (để trống = ảnh mặc định)<input id="mbuc-skin-url" type="url" placeholder="https://example.com/skin.png"></label>
              <div class="mbuc-skin-actions"><button id="mbuc-skin-apply">Apply</button><button id="mbuc-skin-reset-mode">Reset loại này</button><button id="mbuc-skin-reset-all">Reset tất cả</button></div>
              <p id="mbuc-skin-status" role="status">Chọn texture rồi bấm Apply.</p>
            </section>
            <section class="mbuc-skin-tools" id="mbuc-texture-tools" aria-label="Texture Pack Manager">
              <h3>Texture Pack Manager</h3>
              <p>Chọn ảnh PNG/JPG/WebP của bạn để xem trước trong client. Tính năng này hiện quản lý ảnh giao diện/crosshair; chưa thay thế texture block bên trong bộ dựng hình của game.</p>
              <label>Ảnh texture của bạn<input id="mbuc-texture-file" type="file" accept="image/png,image/jpeg,image/webp"></label>
              <div id="mbuc-texture-preview-wrap"><img id="mbuc-texture-preview" alt="Xem trước texture" hidden><span id="mbuc-texture-empty">Chưa chọn ảnh</span></div>
              <div class="mbuc-skin-actions"><button id="mbuc-texture-apply">Dùng làm crosshair</button><button id="mbuc-texture-reset">Khôi phục crosshair</button></div>
              <p id="mbuc-texture-status" role="status">Ảnh được xử lý cục bộ trong tab hiện tại.</p>
            </section>
            <p class="mbuc-note">Các module trực quan: Fullbright, Zoom, Dynamic Crosshair, No Weather, Texture Pack Manager, Keystrokes HUD, FPS/CPS HUD, TextGUI và VietNam HUD. Skin/Cape tiếp tục dùng URL texture đã biết trên miniblox.io. Không chép asset MiniFeather có giấy phép riêng hoặc chưa rõ quyền phân phối.</p>
          </div>
        </section>
        <section id="mbuc-settings" class="mbuc-page" hidden>
          <div class="mbuc-card"><h3>Điều khiển</h3><p><b>H</b> — mở / đóng bảng</p><p>Bảng cố định ở giữa màn hình</p><p>— — thu nhỏ bảng</p><p>× — đóng bảng</p></div>
          <div class="mbuc-card"><h3>Giao diện</h3><label><input type="checkbox" id="mbuc-motion2"> Giảm chuyển động của bảng</label><label><input type="checkbox" id="mbuc-low-fps2"> Chế độ nhẹ (giảm cập nhật HUD)</label></div>
        </section>
        <section id="mbuc-translation" class="mbuc-page" hidden>
          <div class="mbuc-card"><h3>MinibloxTranslationLayer</h3>
            <p>Dự án này là một máy trung gian Node.js chuyển gói tin Miniblox sang giao thức Minecraft 1.8.x. Nó không phải module Chrome và không thể được bật chỉ bằng cách chèn vào client này.</p>
            <p><b>Yêu cầu riêng:</b> Node.js, cài dependencies và chạy máy chủ cục bộ; sau đó kết nối bằng Minecraft client tương thích.</p>
            <p class="mbuc-note">Bảng này chỉ cung cấp thông tin. Nó không kết nối tới localhost, không đọc token và không gửi gói tin trò chơi.</p>
            <p><a href="https://github.com/7GrandDadPGN/MinibloxTranslationLayer" target="_blank" rel="noopener noreferrer" style="color:#70bdff;text-decoration:underline">Mở repository trên GitHub ↗</a></p>
          </div>
        </section>
      </main>
      <footer><span>🇻🇳 MINIBLOX ULTRA</span><span>VIETNAM EDITION · H to toggle</span></footer>`;
    document.body.appendChild(panel);
    // Render the title in the top-level page viewport (important on CrazyGames,
    // where the game itself is usually embedded in a smaller iframe).
    if (window.top === window.self && !document.getElementById('mbuc-vietnam-title')) {
      const vietnamTitle = document.createElement('div');
      vietnamTitle.id = 'mbuc-vietnam-title';
      vietnamTitle.innerHTML = '<span class="mbuc-spectrum-flag" aria-label="Cờ Việt Nam nhiều màu"><i></i><b>★</b></span><span class="mbuc-vietnam-title-text">MINIBLOX ULTRA CLIENT</span><span class="mbuc-vietnam-title-credit">Make by GentleUnicorn.zPx3</span>';
      vietnamTitle.title = 'MINIBLOX ULTRA CLIENT';
      document.body.appendChild(vietnamTitle);
      // Show the spectrum flag for the first 30 seconds after the page/game loads, then remove it entirely.
      setTimeout(() => vietnamTitle.remove(), 30000);
      // Keep the title movable; use viewport coordinates so it stays aligned on CrazyGames.
      let draggingTitle = false, titleStartX = 0, titleStartY = 0, titleLeft = 0, titleTop = 0;
      vietnamTitle.addEventListener('pointerdown', e => {
        if (e.button !== 0) return;
        draggingTitle = true;
        const r = vietnamTitle.getBoundingClientRect();
        titleStartX = e.clientX; titleStartY = e.clientY;
        titleLeft = r.left; titleTop = r.top;
        vietnamTitle.style.left = titleLeft + 'px';
        vietnamTitle.style.top = titleTop + 'px';
        vietnamTitle.style.right = 'auto';
        vietnamTitle.style.transform = 'none';
        try { vietnamTitle.setPointerCapture(e.pointerId); } catch (_) {}
        e.preventDefault();
      });
      vietnamTitle.addEventListener('pointermove', e => {
        if (!draggingTitle) return;
        const maxLeft = Math.max(0, window.innerWidth - vietnamTitle.offsetWidth);
        const maxTop = Math.max(0, window.innerHeight - vietnamTitle.offsetHeight);
        vietnamTitle.style.left = Math.max(0, Math.min(maxLeft, titleLeft + e.clientX - titleStartX)) + 'px';
        vietnamTitle.style.top = Math.max(0, Math.min(maxTop, titleTop + e.clientY - titleStartY)) + 'px';
      });
      const stopTitleDrag = () => { draggingTitle = false; };
      vietnamTitle.addEventListener('pointerup', stopTitleDrag);
      vietnamTitle.addEventListener('pointercancel', stopTitleDrag);
      window.addEventListener('resize', () => {
        const r = vietnamTitle.getBoundingClientRect();
        vietnamTitle.style.left = Math.max(0, Math.min(window.innerWidth - vietnamTitle.offsetWidth, r.left)) + 'px';
        vietnamTitle.style.top = Math.max(0, Math.min(window.innerHeight - vietnamTitle.offsetHeight, r.top)) + 'px';
      });
    }
    const floatButton = document.createElement('button');
    floatButton.id = 'mbuc-float-button';
    floatButton.type = 'button';
    floatButton.textContent = 'MB';
    floatButton.title = 'Mở MiniBlox Ultra Client (H)';
    document.body.appendChild(floatButton);
    floatButton.style.display = 'none';

    // Keep a nullable reference: window.prompt is a browser function, so using the bare name
    // when the banner is disabled can accidentally resolve to that function.
    let startupPrompt = null;
    // CrazyGames: do not show the startup 'PRESS H' banner; H still opens the client.
    const isCrazyGamesHost = /(^|\.)crazygames\.com$/i.test(location.hostname);
    if (!isCrazyGamesHost) {
      startupPrompt = document.createElement('div');
      startupPrompt.id = 'mbuc-b-prompt';
      startupPrompt.innerHTML = '<strong>PRESS H TO OPEN CLIENT</strong><span class="mbuc-prompt-client-name">MINIBLOX ULTRA CLIENT</span><span class="mbuc-prompt-credit">Make by GentleUnicorn.zPx3</span>';
      // The on-screen hint is temporary; the client panel itself stays open until H or Esc is pressed.
      setTimeout(() => startupPrompt.classList.add('mbuc-prompt-off'), 15000);
      document.body.appendChild(startupPrompt);
    }
    let panelTimeout = null;

    const setMotion = v => { panel.classList.toggle('mbuc-reduced', v); const a=document.getElementById('mbuc-motion'), b=document.getElementById('mbuc-motion2'); if(a)a.checked=v;if(b)b.checked=v; };
    ['mbuc-motion','mbuc-motion2'].forEach(id => document.getElementById(id).addEventListener('change', e => setMotion(e.target.checked)));
    let lowLoadMode = false;
    const setLowLoad = v => { lowLoadMode = !!v; const a=document.getElementById('mbuc-low-fps'), b=document.getElementById('mbuc-low-fps2'); if(a)a.checked=lowLoadMode;if(b)b.checked=lowLoadMode; document.documentElement.classList.toggle('mbuc-low-load', lowLoadMode); };
    ['mbuc-low-fps','mbuc-low-fps2'].forEach(id => document.getElementById(id).addEventListener('change', e => setLowLoad(e.target.checked)));
    panel.querySelectorAll('.mbuc-tabs button').forEach(btn => btn.addEventListener('click', () => {
      if (btn.dataset.tab === 'modules') {
        // Open Modules as an independent movable window without hiding the main GUI.
        panel.classList.remove('mbuc-hidden');
        let moduleWindow = document.getElementById('mbuc-modules-window');
        if (!moduleWindow) {
          moduleWindow = document.createElement('div');
          moduleWindow.id = 'mbuc-modules-window';
          moduleWindow.innerHTML = `
            <header class="mbuc-separate-head"><div><strong>🇻🇳 MiniBlox Ultra Client</strong><small>Vietnam Edition · v4.7.1</small></div><button id="mbuc-separate-close" title="Đóng">×</button></header>
            <div class="mbuc-separate-title"><div><h3>Modules</h3><p>Bảng tính năng riêng</p></div><span class="mbuc-key">H</span></div>
            <div class="mbuc-module-grid">
              ${[['ReadHoChiMinh','Hack'],['Fullbright','Visual'],['Dynamic Crosshair','Visual'],['Crosshair Editor','Visual'],['Zoom','Visual'],['No Weather','Visual'],['Texture Pack Manager','Visual'],['PvP HUD','HUD'],['Keystrokes HUD','HUD'],['Clock HUD','HUD'],['FPS HUD','HUD'],['CPS HUD','HUD'],['TextGUI','HUD'],['VietNam HUD','HUD'],['Theme & Profile','UI'],['Player Hearts NameTag','HUD']].map(([n,c])=>`<label class="mbuc-module"><span><small>${c}</small><b>${n}</b></span><input type="checkbox" data-module="${n}"><i></i></label>`).join('')}
            </div>
            <section class="mbuc-skin-tools" aria-label="Custom Skin and Cape">
              <h3>Custom Skin / Cape</h3>
              <p>Đổi texture skin hoặc cape của các tên có sẵn trên miniblox.io. URL ảnh riêng phải là HTTPS trực tiếp tới ảnh.</p>
              <label>Loại texture<select id="mbuc-skin-mode"><option value="skin">Skin</option><option value="cape">Cape</option></select></label>
              <label>Tên skin / cape<select id="mbuc-skin-name"></select></label>
              <label>URL ảnh riêng (để trống = ảnh mặc định)<input id="mbuc-skin-url" type="url" placeholder="https://example.com/skin.png"></label>
              <div class="mbuc-skin-actions"><button id="mbuc-skin-apply">Apply</button><button id="mbuc-skin-reset-mode">Reset loại này</button><button id="mbuc-skin-reset-all">Reset tất cả</button></div>
              <p id="mbuc-skin-status" role="status">Chọn texture rồi bấm Apply.</p>
            </section>
            <p class="mbuc-note">Các module cục bộ: Fullbright, Zoom, Dynamic Crosshair, Keystrokes HUD, TextGUI và VietNam HUD (cờ Việt Nam). Skin/Cape dùng quy tắc chuyển hướng texture của trình duyệt; chỉ hỗ trợ URL texture skin/cape đã biết trên miniblox.io.</p>
            <footer><span>MINIBLOX ULTRA</span><span>Nhấn H để mở/đóng</span></footer>`;
          document.body.appendChild(moduleWindow);
          // Custom Skin/Cape controls are local extension UI; they never read game tokens or send game packets.
          const skinNames = ['alice','bob','techno','thebiggelo','corrupted','diana','strange','endoskeleton','ganyu','georgenotfound','holly','hutao','jake','james','klee','kyoko','adele','chris','deadpool','galactus','heather','ironman','suit','levi','lexi','natalie','remus','sara','transformer','vindicate','adventure','aether','apex','ariel','aurora','celeste','cody','ember','finn','glory','hunter','katie','nova','panda','raven','seraphina','vain','zane','tester','qhyun','banana','sushi','ethan','duck','cat','remlin'];
          const capeNames = ['angry-pig','bao','cloud','cow','creeper','golden-apple','grass-block','heart','pumpkin','maki','mushroom','soul-creeper','sushi','wooden-sword','stone-sword','iron-sword','gold-sword','diamond-sword','emerald-sword'];
          const skinMode = moduleWindow.querySelector('#mbuc-skin-mode'), skinName = moduleWindow.querySelector('#mbuc-skin-name'), skinUrl = moduleWindow.querySelector('#mbuc-skin-url'), skinStatus = moduleWindow.querySelector('#mbuc-skin-status');
          let skinState = {currentSkins:{},currentCapes:{}};
          const skinMap = () => skinMode.value === 'cape' ? skinState.currentCapes : skinState.currentSkins;
          const fillSkinNames = () => { const old=skinName.value, names=skinMode.value==='cape'?capeNames:skinNames; skinName.innerHTML=names.map(n=>`<option value="${n}">${n}${skinMap()[n]?' · custom':''}</option>`).join(''); if(names.includes(old)) skinName.value=old; skinUrl.value=skinMap()[skinName.value]||''; };
          const skinMessage = (msg, ok=true) => { skinStatus.textContent=msg; skinStatus.style.color=ok?'#7cffb1':'#ff8b8b'; };
          chrome.runtime.sendMessage({type:'getState'},res=>{ if(res?.ok){skinState.currentSkins=res.currentSkins||{};skinState.currentCapes=res.currentCapes||{};} fillSkinNames(); });
          skinMode.addEventListener('change',fillSkinNames); skinName.addEventListener('change',()=>{skinUrl.value=skinMap()[skinName.value]||'';});
          moduleWindow.querySelector('#mbuc-skin-apply').addEventListener('click',()=>{const type=skinMode.value,name=skinName.value,url=skinUrl.value.trim();if(url){try{const parsed=new URL(url);if(parsed.protocol!=='https:')throw new Error();}catch(_){skinMessage('Hãy nhập URL ảnh HTTPS hợp lệ.',false);return;}} const msg=type==='cape'?{type:'setCape',capeName:name,customUrl:url}:{type:'setSkin',skinName:name,customUrl:url};chrome.runtime.sendMessage(msg,res=>{if(res?.ok){const map=type==='cape'?skinState.currentCapes:skinState.currentSkins;if(url)map[name]=url;else delete map[name];fillSkinNames();skinMessage('Đã áp dụng. Tải lại trang MiniBlox để texture được tải lại.');}else skinMessage('Không áp dụng được: '+(res?.error||'lỗi không xác định'),false);});});
          moduleWindow.querySelector('#mbuc-skin-reset-mode').addEventListener('click',()=>{const type=skinMode.value;chrome.runtime.sendMessage({type:type==='cape'?'resetCapes':'resetSkins'},res=>{if(res?.ok){if(type==='cape')skinState.currentCapes={};else skinState.currentSkins={};fillSkinNames();skinMessage('Đã reset loại texture này. Tải lại trang MiniBlox.');}else skinMessage('Reset thất bại.',false);});});
          moduleWindow.querySelector('#mbuc-skin-reset-all').addEventListener('click',()=>chrome.runtime.sendMessage({type:'resetAll'},res=>{if(res?.ok){skinState={currentSkins:{},currentCapes:{}};fillSkinNames();skinMessage('Đã reset tất cả skin/cape. Tải lại trang MiniBlox.');}else skinMessage('Reset thất bại.',false);}));
          fillSkinNames();
          const moduleHead = moduleWindow.querySelector('.mbuc-separate-head');
          moduleHead.style.cursor='grab';
          let moduleDragging=false, msx=0, msy=0, mlx=0, mly=0;
          moduleHead.addEventListener('pointerdown', e => {
            if(e.target.closest('button')) return;
            moduleDragging=true;
            const r=moduleWindow.getBoundingClientRect();
            msx=e.clientX; msy=e.clientY; mlx=r.left; mly=r.top;
            moduleWindow.style.transform='none'; moduleWindow.style.left=mlx+'px'; moduleWindow.style.top=mly+'px';
            moduleHead.setPointerCapture(e.pointerId);
          });
          moduleHead.addEventListener('pointermove', e => {
            if(!moduleDragging)return;
            moduleWindow.style.left=Math.max(0,Math.min(window.innerWidth-moduleWindow.offsetWidth,mlx+e.clientX-msx))+'px';
            moduleWindow.style.top=Math.max(0,Math.min(window.innerHeight-50,mly+e.clientY-msy))+'px';
          });
          moduleHead.addEventListener('pointerup', ()=>moduleDragging=false);
          moduleHead.addEventListener('pointercancel', ()=>moduleDragging=false);
          document.getElementById('mbuc-separate-close').addEventListener('click', () => moduleWindow.classList.add('mbuc-separate-hidden'));
        }
        moduleWindow.classList.remove('mbuc-separate-hidden');
        return;
      }
      panel.querySelectorAll('.mbuc-tabs button').forEach(x=>x.classList.toggle('active', x===btn));
      panel.querySelectorAll('.mbuc-page').forEach(p=>p.hidden = p.id !== 'mbuc-' + btn.dataset.tab);
    }));
    const moduleClose = document.getElementById('mbuc-modules-close');
    if (moduleClose) moduleClose.addEventListener('click', () => {
      document.getElementById('mbuc-modules-window')?.classList.add('mbuc-separate-hidden');
      panel.classList.remove('mbuc-hidden');
    });
    document.getElementById('mbuc-close').addEventListener('click', closePanelAndShowPrompt);
    document.getElementById('mbuc-min').addEventListener('click', () => panel.classList.toggle('mbuc-minimized'));

    // Drag main rectangular panel by its title bar
    {
      let dragging=false, startX=0, startY=0, startLeft=0, startTop=0;
      const titlebar=document.getElementById('mbuc-titlebar');
      titlebar.style.cursor='grab';
      titlebar.addEventListener('pointerdown', e => {
        if (e.target.closest('button')) return;
        dragging=true;
        const r=panel.getBoundingClientRect();
        startX=e.clientX; startY=e.clientY; startLeft=r.left; startTop=r.top;
        panel.style.transform='none'; panel.style.left=startLeft+'px'; panel.style.top=startTop+'px';
        titlebar.setPointerCapture(e.pointerId);
      });
      titlebar.addEventListener('pointermove', e => {
        if(!dragging)return;
        panel.style.left=Math.max(0,Math.min(window.innerWidth-panel.offsetWidth,startLeft+e.clientX-startX))+'px';
        panel.style.top=Math.max(0,Math.min(window.innerHeight-50,startTop+e.clientY-startY))+'px';
      });
      titlebar.addEventListener('pointerup', ()=>dragging=false);
      titlebar.addEventListener('pointercancel', ()=>dragging=false);
    }
    // Real, local visual/accessibility modules. No game-memory or combat automation.
    const active = new Set();
    let zoomLevel = 1.25;
    function makeWidgetDraggable(el, handle) {
      if (!el || !handle || handle.dataset.dragReady === '1') return;
      handle.dataset.dragReady = '1';
      handle.style.cursor = 'grab';
      handle.style.touchAction = 'none';
      let dragging = false, sx = 0, sy = 0, sl = 0, st = 0;
      handle.addEventListener('pointerdown', e => {
        if (e.button !== 0 || e.target.closest('button,a,input')) return;
        dragging = true;
        const r = el.getBoundingClientRect();
        sx = e.clientX; sy = e.clientY; sl = r.left; st = r.top;
        el.style.left = sl + 'px'; el.style.top = st + 'px';
        el.style.right = 'auto'; el.style.bottom = 'auto'; el.style.transform = 'none';
        try { handle.setPointerCapture(e.pointerId); } catch (_) {}
        e.preventDefault();
      });
      handle.addEventListener('pointermove', e => {
        if (!dragging) return;
        const maxLeft = Math.max(0, window.innerWidth - el.offsetWidth);
        const maxTop = Math.max(0, window.innerHeight - el.offsetHeight);
        el.style.left = Math.max(0, Math.min(maxLeft, sl + e.clientX - sx)) + 'px';
        el.style.top = Math.max(0, Math.min(maxTop, st + e.clientY - sy)) + 'px';
      });
      const stop = () => { dragging = false; };
      handle.addEventListener('pointerup', stop);
      handle.addEventListener('pointercancel', stop);
      window.addEventListener('resize', () => {
        if (el.style.left) el.style.left = Math.max(0, Math.min(window.innerWidth - el.offsetWidth, parseFloat(el.style.left) || 0)) + 'px';
        if (el.style.top) el.style.top = Math.max(0, Math.min(window.innerHeight - el.offsetHeight, parseFloat(el.style.top) || 0)) + 'px';
      });
    }
    const ensureTextGUI = () => {
      let el = document.getElementById('mbuc-textgui');
      if (!el) {
        el = document.createElement('div'); el.id = 'mbuc-textgui';
        el.innerHTML = '<div class="mbuc-widget-drag-head"><strong class="mbuc-textgui-heading">ACTIVE MODULES</strong><span>⠿</span></div><div class="mbuc-textgui-list"></div>';
        document.body.appendChild(el);
        makeWidgetDraggable(el, el.querySelector('.mbuc-widget-drag-head'));
      }
      return el;
    };
    function refreshTextGUI() {
      const el = ensureTextGUI();
      const names = [...active].filter(x => ['Fullbright','Zoom','Dynamic Crosshair','Crosshair Editor','PvP HUD','Theme & Profile','No Weather','Texture Pack Manager','Keystrokes HUD','Clock HUD','FPS HUD','CPS HUD','TextGUI','VietNam HUD','Player Hearts NameTag'].includes(x));
      if (!el.querySelector('.mbuc-widget-drag-head')) {
        el.innerHTML = '<div class="mbuc-widget-drag-head"><strong class="mbuc-textgui-heading">ACTIVE MODULES</strong><span>⠿</span></div><div class="mbuc-textgui-list"></div>';
        makeWidgetDraggable(el, el.querySelector('.mbuc-widget-drag-head'));
      }
      const list = el.querySelector('.mbuc-textgui-list');
      if (list) list.innerHTML = names.map(n => { const value = n === 'FPS HUD' ? String(fps > 0 ? fps : '--') : n === 'CPS HUD' ? String(clicks.length) : 'ON'; return `<div>${n} <span>${value}</span></div>`; }).join('');
      // Show the right-side list automatically whenever any module is enabled.
      el.classList.toggle('mbuc-widget-on', names.length > 0);
    }
    let textWriteReady = false;
    function ensureTextWriteGUI() {
      let box = document.getElementById('mbuc-textwrite-controls');
      if (box) return box;
      box = document.createElement('div'); box.id = 'mbuc-textwrite-controls';
      box.innerHTML = '<div class="mbuc-tw-title">TextWriteGUI <button type="button" id="mbuc-tw-close">×</button></div><label>Màu chữ <input id="mbuc-tw-color" type="color" value="#ffffff"></label><label>Cỡ chữ <input id="mbuc-tw-size" type="range" min="12" max="72" value="30"><output id="mbuc-tw-size-value">30 px</output></label><textarea id="mbuc-tw-input" rows="3" maxlength="240" placeholder="Ghi chữ muốn hiện trên màn hình..."></textarea><label><input id="mbuc-tw-shadow" type="checkbox" checked> Bóng chữ</label><label><input id="mbuc-tw-sparkle" type="checkbox" checked> Hiệu ứng lấp lánh ✨</label><label><input id="mbuc-tw-board" type="checkbox" checked> Hiện bảng nền</label><p>Kéo thanh tiêu đề để di chuyển bảng. Có thể bật/tắt nền bảng.</p>';
      document.body.appendChild(box);
      const output = document.createElement('div'); output.id = 'mbuc-textwrite-output'; output.textContent = '';
      document.body.appendChild(output);
      const input = box.querySelector('#mbuc-tw-input'), color = box.querySelector('#mbuc-tw-color'), shadow = box.querySelector('#mbuc-tw-shadow'), size = box.querySelector('#mbuc-tw-size'), sizeValue = box.querySelector('#mbuc-tw-size-value'), sparkle = box.querySelector('#mbuc-tw-sparkle'), board = box.querySelector('#mbuc-tw-board');
      const update = () => { output.textContent = input.value; output.style.color = color.value; output.style.fontSize = size.value + 'px'; sizeValue.textContent = size.value + ' px'; output.classList.toggle('mbuc-tw-sparkle', sparkle.checked); output.classList.toggle('mbuc-tw-board', board.checked); output.style.textShadow = shadow.checked ? '2px 2px 4px #000, 0 0 8px ' + color.value : 'none'; output.style.display = active.has('TextGUI') && input.value.length ? 'block' : 'none'; };
      input.addEventListener('input', update); color.addEventListener('input', update); shadow.addEventListener('change', update); size.addEventListener('input', update); sparkle.addEventListener('change', update); board.addEventListener('change', update);
      box.querySelector('#mbuc-tw-close').addEventListener('click', () => { box.style.display='none'; output.style.display='none'; const cb = document.querySelector('#mbuc-modules-window input[data-module="TextGUI"]') || document.querySelector('#mbuc-panel input[data-module="TextGUI"]'); if (cb) { cb.checked=false; applyModule('TextGUI', false); document.querySelectorAll('input[data-module="TextGUI"]').forEach(x=>x.checked=false); } });
      makeWidgetDraggable(box, box.querySelector('.mbuc-tw-title'));
      textWriteReady = true;
      return box;
    }
    const originalFilters = new Map();
    const weatherVisibility = new Map();
    let customCrosshairDataUrl = '';
    let defaultCrosshairMarkup = '<span>+</span><small>⠿</small>';
    function scanWeatherNodes() {
      // Safe visual-only attempt: hide explicitly named weather DOM nodes if the site exposes them.
      // Canvas-rendered weather needs a supported game texture API and is not force-patched here.
      document.querySelectorAll('[class*="weather" i], [id*="weather" i], [class*="rain" i], [id*="rain" i], [class*="snow" i], [id*="snow" i]').forEach(el => {
        if (el.id === 'mbuc-texture-tools' || el.closest('#mbuc-panel,#mbuc-modules-window')) return;
        if (!weatherVisibility.has(el)) weatherVisibility.set(el, el.style.visibility);
        el.style.visibility = 'hidden';
      });
    }
    function restoreWeatherNodes() {
      for (const [el, visibility] of weatherVisibility) {
        if (el && el.isConnected) el.style.visibility = visibility;
      }
      weatherVisibility.clear();
    }
    const ensureCrosshair = () => {
      let el = document.getElementById('mbuc-crosshair');
      if (!el) { el = document.createElement('div'); el.id = 'mbuc-crosshair'; el.innerHTML = '<span>+</span><small>⠿</small>'; document.body.appendChild(el); makeWidgetDraggable(el, el); }
      return el;
    };
    document.body.addEventListener('change', e => {
      if (e.target?.id !== 'mbuc-texture-file') return;
      const file = e.target.files && e.target.files[0];
      const status = document.getElementById('mbuc-texture-status');
      const preview = document.getElementById('mbuc-texture-preview');
      const empty = document.getElementById('mbuc-texture-empty');
      if (!file || !status || !preview) return;
      if (!/^image\/(png|jpeg|webp)$/.test(file.type) || file.size > 4 * 1024 * 1024) {
        status.textContent = 'Chỉ nhận PNG/JPG/WebP tối đa 4 MB.'; return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        customCrosshairDataUrl = String(reader.result || '');
        preview.src = customCrosshairDataUrl; preview.hidden = false;
        if (empty) empty.hidden = true;
        status.textContent = 'Đã tải ảnh vào xem trước. Bấm “Dùng làm crosshair” để áp dụng.';
      };
      reader.onerror = () => { status.textContent = 'Không đọc được ảnh này.'; };
      reader.readAsDataURL(file);
    });
    document.body.addEventListener('click', e => {
      if (e.target?.id === 'mbuc-texture-apply') {
        const status = document.getElementById('mbuc-texture-status');
        if (!customCrosshairDataUrl) { if (status) status.textContent = 'Chọn ảnh trước nhé.'; return; }
        const cross = ensureCrosshair();
        cross.innerHTML = `<img class="mbuc-custom-crosshair-image" src="${customCrosshairDataUrl}" alt="Custom crosshair"><small>⠿</small>`;
        if (active.has('Dynamic Crosshair')) cross.classList.add('mbuc-widget-on');
        if (status) status.textContent = 'Đã áp dụng ảnh làm crosshair trong tab hiện tại.';
      }
      if (e.target?.id === 'mbuc-texture-reset') {
        customCrosshairDataUrl = '';
        const cross = ensureCrosshair(); cross.innerHTML = defaultCrosshairMarkup;
        const file = document.getElementById('mbuc-texture-file'); if (file) file.value = '';
        const preview = document.getElementById('mbuc-texture-preview'); if (preview) { preview.removeAttribute('src'); preview.hidden = true; }
        const empty = document.getElementById('mbuc-texture-empty'); if (empty) empty.hidden = false;
        const status = document.getElementById('mbuc-texture-status'); if (status) status.textContent = 'Đã khôi phục crosshair mặc định.';
      }
    });
    const ensureKeys = () => {
      let el = document.getElementById('mbuc-keystrokes');
      if (!el) {
        el = document.createElement('div'); el.id = 'mbuc-keystrokes';
        el.innerHTML = '<div class="mbuc-widget-drag-head"><b>KEYSTROKES</b><span>⠿</span></div><div class="mbuc-keys-w-row"><span data-key="W">W</span></div><div class="mbuc-keys-wasd"><span data-key="A">A</span><span data-key="S">S</span><span data-key="D">D</span></div><div class="mbuc-keys-space-row"><span data-key="SPACE">SPACE</span></div><div class="mbuc-keys-mouse"><span data-key="LMB">LMB</span><span data-key="RMB">RMB</span></div>';
        document.body.appendChild(el); makeWidgetDraggable(el, el.querySelector('.mbuc-widget-drag-head'));
      }
      return el;
    };
    const ensureClock = () => {
      let el = document.getElementById('mbuc-clock');
      if (!el) { el = document.createElement('div'); el.id = 'mbuc-clock'; el.innerHTML = '<span class="mbuc-clock-value"></span><span class="mbuc-widget-grip"> ⠿</span>'; el.querySelector('.mbuc-clock-value').textContent = new Date().toLocaleTimeString(); document.body.appendChild(el); makeWidgetDraggable(el, el); }
      return el;
    };
    const ensureVietNamHud = () => {
      let el = document.getElementById('mbuc-vietnam-hud');
      if (!el) {
        el = document.createElement('div');
        el.id = 'mbuc-vietnam-hud';
        el.innerHTML = '<div class="mbuc-vietnam-hud-head"><span>VIETNAM HUD</span><span>⠿</span></div><div class="mbuc-vietnam-flag" role="img" aria-label="Cờ Việt Nam"><span>★</span></div><div class="mbuc-vietnam-caption">VIỆT NAM</div>';
        document.body.appendChild(el);
        makeWidgetDraggable(el, el.querySelector('.mbuc-vietnam-hud-head'));
      }
      return el;
    };
    const ensureMetricHud = (kind) => {
      const id = kind === 'FPS' ? 'mbuc-fps-hud' : 'mbuc-cps-hud';
      let el = document.getElementById(id);
      if (el) return el;
      el = document.createElement('div');
      el.id = id;
      el.className = 'mbuc-metric-hud';
      el.innerHTML = `<div class="mbuc-metric-drag" title="Kéo để di chuyển"><span>${kind} HUD</span><span class="mbuc-drag-dots">⠿</span></div><div class="mbuc-metric-value">${kind === 'FPS' ? '--' : '0'}</div>`;
      el.style.left = '18px';
      el.style.right = 'auto';
      el.style.top = kind === 'FPS' ? '95px' : '180px';
      document.body.appendChild(el);
      const handle = el.querySelector('.mbuc-metric-drag');
      let dragging = false, sx = 0, sy = 0, sl = 0, st = 0;
      handle.addEventListener('pointerdown', e => {
        if (e.button !== 0) return;
        dragging = true;
        const r = el.getBoundingClientRect();
        sx = e.clientX; sy = e.clientY; sl = r.left; st = r.top;
        el.style.left = sl + 'px'; el.style.top = st + 'px'; el.style.right = 'auto';
        handle.setPointerCapture(e.pointerId);
        e.preventDefault();
      });
      handle.addEventListener('pointermove', e => {
        if (!dragging) return;
        const maxLeft = Math.max(0, window.innerWidth - el.offsetWidth);
        const maxTop = Math.max(0, window.innerHeight - el.offsetHeight);
        el.style.left = Math.max(0, Math.min(maxLeft, sl + e.clientX - sx)) + 'px';
        el.style.top = Math.max(0, Math.min(maxTop, st + e.clientY - sy)) + 'px';
      });
      const stopDrag = () => { dragging = false; };
      handle.addEventListener('pointerup', stopDrag);
      handle.addEventListener('pointercancel', stopDrag);
      return el;
    };
    // Best-effort name-tag health overlay: only renders hearts when the page exposes a
    // name-tag element AND an explicit health value. Canvas-only nametags are unsupported.
    const playerHeartNodes = new Map();
    function scanPlayerHearts() {
      const selectors = '[class*="nametag" i], [class*="name-tag" i], [class*="player-name" i], [data-player-name]';
      document.querySelectorAll(selectors).forEach(el => {
        if (!el || el.closest('#mbuc-panel,#mbuc-modules-window')) return;
        // MiniBlox's intended full-health scale is 20 HP. Read only explicit page data;
        // never guess a player's current health when the game does not expose it.
        const raw = el.getAttribute('data-health') || el.getAttribute('data-hp') || el.getAttribute('aria-valuenow') || el.dataset.health;
        const maxRaw = el.getAttribute('data-max-health') || el.getAttribute('aria-valuemax') || el.dataset.maxHealth || '20';
        const health = Number(raw), maxHealth = Number(maxRaw);
        if (!Number.isFinite(health) || !Number.isFinite(maxHealth) || maxHealth <= 0) return;
        let badge = playerHeartNodes.get(el);
        if (!badge) {
          badge = document.createElement('span');
          badge.className = 'mbuc-player-hearts';
          el.appendChild(badge);
          playerHeartNodes.set(el, badge);
          el.dataset.mbucHeartsDone = '1';
        }
        const hp20 = Math.max(0, Math.min(20, Math.round(health / maxHealth * 20)));
        const hearts = Math.ceil(hp20 / 2);
        badge.setAttribute('aria-label', `Health ${hp20}/20`);
        badge.textContent = ' ♥'.repeat(hearts) + ` ${hp20}/20`;
      });
    }
    function restorePlayerHearts() {
      for (const [el, badge] of playerHeartNodes) {
        if (badge?.isConnected) badge.remove();
        if (el?.dataset) delete el.dataset.mbucHeartsDone;
      }
      playerHeartNodes.clear();
    }
    function applyModule(name, enabled) {
      if (enabled) active.add(name); else active.delete(name);
      if (name === 'Fullbright') {
        document.querySelectorAll('canvas, video, #game, .game-container').forEach(el => {
          if (enabled) {
            if (!originalFilters.has(el)) originalFilters.set(el, el.style.filter);
            el.style.filter = 'brightness(1.45) contrast(1.08)';
          } else if (originalFilters.has(el)) { el.style.filter = originalFilters.get(el); originalFilters.delete(el); }
        });
      }
      if (name === 'Zoom') {
        document.querySelectorAll('canvas').forEach(el => {
          if (enabled) { el.style.transform = `scale(${zoomLevel})`; el.style.transformOrigin = 'center center'; }
          else { el.style.transform = ''; el.style.transformOrigin = ''; }
        });
      }
      if (name === 'Dynamic Crosshair' || name === 'Crosshair Editor') ensureCrosshair().classList.toggle('mbuc-widget-on', enabled);
      if (name === 'PvP HUD') {
        ['Keystrokes HUD','FPS HUD','CPS HUD'].forEach(n => { if (enabled) active.add(n); else active.delete(n); });
        ensureKeys().classList.toggle('mbuc-widget-on', enabled);
        ensureMetricHud('FPS').classList.toggle('mbuc-metric-on', enabled || active.has('FPS HUD'));
        ensureMetricHud('CPS').classList.toggle('mbuc-metric-on', enabled || active.has('CPS HUD'));
        document.querySelectorAll('input[data-module="Keystrokes HUD"],input[data-module="FPS HUD"],input[data-module="CPS HUD"]').forEach(cb => cb.checked = enabled);
      }
      if (name === 'Theme & Profile') { document.documentElement.classList.toggle('mbuc-vietnam-theme', enabled); }
      if (name === 'ReadHoChiMinh') {
        let bio = document.getElementById('mbuc-ho-chi-minh-window');
        if (enabled && !bio) {
          bio = document.createElement('section'); bio.id = 'mbuc-ho-chi-minh-window';
          bio.innerHTML = `<header class="mbuc-hcm-head"><div><small>NHÂN VẬT LỊCH SỬ VIỆT NAM</small><h2>Chủ tịch Hồ Chí Minh</h2></div><button type="button" aria-label="Đóng">×</button></header><article><h3>Tiểu sử và cuộc đời</h3><p>Hồ Chí Minh (1890–1969), tên khai sinh Nguyễn Sinh Cung, là nhà cách mạng và lãnh tụ của phong trào giành độc lập Việt Nam. Người sinh ngày 19 tháng 5 năm 1890 tại làng Hoàng Trù, xã Kim Liên, huyện Nam Đàn, Nghệ An.</p><h3>Hành trình tìm đường cứu nước</h3><p>Ngày 5 tháng 6 năm 1911, Người rời Bến Nhà Rồng, bắt đầu hành trình qua nhiều quốc gia để tìm con đường giải phóng dân tộc. Trong quá trình hoạt động, Người sử dụng nhiều tên gọi, trong đó có Nguyễn Ái Quốc và Hồ Chí Minh.</p><h3>Vai trò lịch sử</h3><p>Người góp phần thành lập Đảng Cộng sản Việt Nam vào năm 1930. Ngày 2 tháng 9 năm 1945, tại Quảng trường Ba Đình, Hà Nội, Người đọc Tuyên ngôn Độc lập, khai sinh nước Việt Nam Dân chủ Cộng hòa.</p><h3>Di sản</h3><p>Hồ Chí Minh qua đời ngày 2 tháng 9 năm 1969. Tư tưởng, hoạt động cách mạng và lời kêu gọi độc lập dân tộc của Người có ảnh hưởng sâu rộng trong lịch sử Việt Nam hiện đại. Khi tìm hiểu, nên tham khảo thêm tài liệu lịch sử và nguồn lưu trữ đáng tin cậy.</p><p class="mbuc-hcm-note">Bảng thông tin lịch sử • Kéo thanh tiêu đề để di chuyển</p></article>`;
          document.body.appendChild(bio);
          const head=bio.querySelector('header'); let drag=false,dx=0,dy=0;
          head.addEventListener('pointerdown',e=>{if(e.target.closest('button'))return;drag=true;dx=e.clientX-bio.offsetLeft;dy=e.clientY-bio.offsetTop;head.setPointerCapture?.(e.pointerId)});
          head.addEventListener('pointermove',e=>{if(drag){bio.style.left=(e.clientX-dx)+'px';bio.style.top=(e.clientY-dy)+'px'}});
          head.addEventListener('pointerup',()=>drag=false);
          bio.querySelector('button').addEventListener('click',()=>{bio.style.display='none';document.querySelectorAll('input[data-module="ReadHoChiMinh"]').forEach(cb=>cb.checked=false);active.delete('ReadHoChiMinh')});
        }
        if (bio) bio.style.display = enabled ? 'block' : 'none';
      }

      if (name === 'TextGUI') {
        const tw = ensureTextWriteGUI();
        // Force the controls and output above the embedded CrazyGames canvas/iframe.
        if (tw.parentElement !== document.body) document.body.appendChild(tw);
        tw.style.cssText += ';position:fixed!important;left:24px!important;top:120px!important;width:min(320px,calc(100vw - 32px))!important;pointer-events:auto!important;';
        tw.style.setProperty('display', enabled ? 'block' : 'none', 'important');
        tw.style.setProperty('visibility', enabled ? 'visible' : 'hidden', 'important');
        tw.style.setProperty('opacity', enabled ? '1' : '0', 'important');
        tw.style.setProperty('z-index', '2147483647', 'important');
        const out = document.getElementById('mbuc-textwrite-output');
        if (out) {
          if (out.parentElement !== document.body) document.body.appendChild(out);
          out.style.setProperty('position','fixed','important');
          out.style.setProperty('z-index','2147483646','important');
          out.style.setProperty('pointer-events','none','important');
          out.style.setProperty('display', enabled && tw.querySelector('#mbuc-tw-input').value ? 'block' : 'none', 'important');
        }
        if (enabled) {
          // Keep the panel open even when the game canvas has focus; do not steal focus automatically.
          tw.querySelector('#mbuc-tw-input')?.setAttribute('autocomplete','off');
          tw.querySelector('#mbuc-tw-input')?.focus({preventScroll:true});
        }
      }
      if (name === 'No Weather') { if (enabled) scanWeatherNodes(); else restoreWeatherNodes(); }
      if (name === 'Texture Pack Manager') {
        const tools = document.getElementById('mbuc-texture-tools');
        if (tools) { tools.style.outline = enabled ? '1px solid #168cff' : ''; tools.scrollIntoView({block:'nearest',behavior:'smooth'}); }
      }
      if (name === 'Keystrokes HUD') ensureKeys().classList.toggle('mbuc-widget-on', enabled);
      if (name === 'Clock HUD') ensureClock().classList.toggle('mbuc-widget-on', enabled);
      if (name === 'FPS HUD') ensureMetricHud('FPS').classList.toggle('mbuc-metric-on', enabled);
      if (name === 'CPS HUD') ensureMetricHud('CPS').classList.toggle('mbuc-metric-on', enabled);
      if (name === 'VietNam HUD') ensureVietNamHud().classList.toggle('mbuc-vietnam-on', enabled);
      if (name === 'Player Hearts NameTag') { if (enabled) scanPlayerHearts(); else restorePlayerHearts(); }
      refreshTextGUI();
      const note = document.querySelector('#mbuc-modules-window .mbuc-note');
      if (note) note.textContent = 'Hoạt động: ' + ([...active].filter(x => ['Fullbright','Zoom','Dynamic Crosshair','Crosshair Editor','PvP HUD','Theme & Profile','No Weather','Texture Pack Manager','Keystrokes HUD','Clock HUD','FPS HUD','CPS HUD','TextGUI','VietNam HUD','Player Hearts NameTag'].includes(x)).join(', ') || 'không có') + '. Các module gameplay/đối thủ cần API game nên chưa được giả lập là đang chạy.';
    }
    panel.addEventListener('change', e => {
      const input = e.target;
      if (!input.matches('input[data-module]')) return;
      applyModule(input.dataset.module, input.checked);
      // Mirror state between the main hidden list and the separate Modules window.
      document.querySelectorAll(`input[data-module="${CSS.escape(input.dataset.module)}"]`).forEach(other => { if (other !== input) other.checked = input.checked; });
    });
    document.addEventListener('change', e => {
      const input = e.target;
      if (!(input instanceof HTMLInputElement) || !input.matches('input[data-module]')) return;
      applyModule(input.dataset.module, input.checked);
      document.querySelectorAll(`input[data-module="${CSS.escape(input.dataset.module)}"]`).forEach(other => { if (other !== input) other.checked = input.checked; });
    }, true);
    const heldKeys = new Set();
    const setKeyHeld = (k, isHeld) => {
      document.querySelectorAll(`#mbuc-keystrokes [data-key="${k}"]`).forEach(x => x.classList.toggle('mbuc-key-held', isHeld));
    };
    window.addEventListener('keydown', e => {
      const k = e.code === 'Space' ? 'SPACE' : e.key.toUpperCase();
      if (['W','A','S','D','SPACE'].includes(k)) { heldKeys.add(k); setKeyHeld(k, true); }
    });
    window.addEventListener('keyup', e => {
      const k = e.code === 'Space' ? 'SPACE' : e.key.toUpperCase();
      if (['W','A','S','D','SPACE'].includes(k)) { heldKeys.delete(k); setKeyHeld(k, false); }
    });
    window.addEventListener('mousedown', e => { const k = e.button === 0 ? 'LMB' : e.button === 2 ? 'RMB' : ''; if (k) setKeyHeld(k, true); });
    window.addEventListener('mouseup', e => { const k = e.button === 0 ? 'LMB' : e.button === 2 ? 'RMB' : ''; if (k) setKeyHeld(k, false); });
    window.addEventListener('blur', () => { ['W','A','S','D','SPACE','LMB','RMB'].forEach(k => setKeyHeld(k, false)); heldKeys.clear(); });
    floatButton.addEventListener('click', () => togglePanel());

    function closePanelAndShowPrompt(){
      panel.classList.add('mbuc-hidden');
      const moduleWindow = document.getElementById('mbuc-modules-window');
      if (moduleWindow) moduleWindow.classList.add('mbuc-separate-hidden');
      if (startupPrompt) startupPrompt.classList.remove('mbuc-prompt-off');
      if (panelTimeout) { clearTimeout(panelTimeout); panelTimeout = null; }
    }
    function togglePanel(){
      const moduleWindow = document.getElementById('mbuc-modules-window');
      if (!panel.classList.contains('mbuc-hidden')) {
        closePanelAndShowPrompt();
        return;
      }
      if (moduleWindow && !moduleWindow.classList.contains('mbuc-separate-hidden')) moduleWindow.classList.add('mbuc-separate-hidden');
      panel.classList.remove('mbuc-hidden');
      if (startupPrompt) startupPrompt.classList.add('mbuc-prompt-off');
      if (panelTimeout) { clearTimeout(panelTimeout); panelTimeout = null; }
    }
    window.addEventListener('message', e => {
      if (!e.data || e.data.type !== 'MBUC_TOGGLE_CLIENT') return;
      togglePanel();
    });
    window.addEventListener('keydown', e => {
      const target = e.target || document.activeElement;
      const typing = target && (['INPUT','TEXTAREA','SELECT'].includes(target.tagName) || target.isContentEditable);
      if(((e.key && e.key.toLowerCase()==='h') || e.code==='KeyH') && !e.repeat && !typing){ e.preventDefault(); e.stopPropagation(); togglePanel(); }
      if(e.key==='Escape') closePanelAndShowPrompt();
    }, true);
    setInterval(() => {
      const f=document.getElementById('mbuc-fps'), c=document.getElementById('mbuc-cps');
      if(f) f.textContent=fps > 0 ? String(fps) : '--';
      const now=Date.now(); while(clicks.length && now-clicks[0]>1000) clicks.shift();
      if(c)c.textContent=clicks.length;
      const clock=document.getElementById('mbuc-clock'); if(clock && active.has('Clock HUD')) { const v=clock.querySelector('.mbuc-clock-value'); if(v) v.textContent=new Date().toLocaleTimeString(); else clock.textContent=new Date().toLocaleTimeString(); }
      const fpsHudValue = document.querySelector('#mbuc-fps-hud .mbuc-metric-value');
      if (fpsHudValue && active.has('FPS HUD')) fpsHudValue.textContent = fps > 0 ? String(fps) : '--';
      const cpsHudValue = document.querySelector('#mbuc-cps-hud .mbuc-metric-value');
      if (cpsHudValue && active.has('CPS HUD')) cpsHudValue.textContent = String(clicks.length);
      if (active.has('FPS HUD') || active.has('CPS HUD') || active.has('TextGUI')) refreshTextGUI();
      if (active.has('No Weather')) scanWeatherNodes();
      if (active.has('Player Hearts NameTag')) scanPlayerHearts();
    }, 1000);
    panel.style.left='50%'; panel.style.top='50%'; panel.style.transform='translate(-50%,-50%)';
  }
  const timer = setInterval(() => { if(document.body){ clearInterval(timer); build(); } }, 100);
})();