const SKINS = ["alice", "bob", "techno", "thebiggelo", "corrupted", "diana", "strange", "endoskeleton", "ganyu", "georgenotfound", "holly", "hutao", "jake", "james", "klee", "kyoko", "adele", "chris", "deadpool", "galactus", "heather", "ironman", "suit", "levi", "lexi", "natalie", "remus", "sara", "transformer", "vindicate", "adventure", "aether", "apex", "ariel", "aurora", "celeste", "cody", "ember", "finn", "glory", "hunter", "katie", "nova", "panda", "raven", "seraphina", "vain", "zane", "tester", "qhyun", "banana", "sushi", "ethan", "duck", "cat", "remlin"];
const CAPES = ["angry-pig", "bao", "cloud", "cow", "creeper", "golden-apple", "grass-block", "heart", "pumpkin", "maki", "mushroom", "soul-creeper", "sushi", "wooden-sword", "stone-sword", "iron-sword", "gold-sword", "diamond-sword", "emerald-sword"];
const BASE_SKIN_PATH = "https://miniblox.io/textures/entity/skins/";
const BASE_CAPE_PATH = "https://miniblox.io/textures/entity/capes/";
function ruleId(type, name) { const list = type === 'cape' ? CAPES : SKINS; const i=list.indexOf(name); if(i<0) throw new Error('Unknown '+type+' name'); return (type==='cape'?2000:1000)+i; }
function filterFor(type,name) { const base=type==='cape'?'||miniblox.io/textures/entity/capes/':'||miniblox.io/textures/entity/skins/'; return base+name+'.png'; }
async function setTexture(type,name,url='') {
 if(!(type==='skin'?SKINS:CAPES).includes(name)) throw new Error('Unknown texture name');
 const clean=(url||'').trim();
 if(clean) { const parsed=new URL(clean); if(parsed.protocol!=='https:') throw new Error('Use a direct HTTPS image URL.'); }
 const id=ruleId(type,name), original=(type==='cape'?BASE_CAPE_PATH:BASE_SKIN_PATH)+name+'.png';
 await chrome.declarativeNetRequest.updateDynamicRules({removeRuleIds:[id],addRules:[{id,priority:1,action:{type:'redirect',redirect:{url:clean||original}},condition:{urlFilter:filterFor(type,name),resourceTypes:['image']}}]});
 const key=type==='cape'?'currentCapes':'currentSkins'; const d=await chrome.storage.local.get([key]); const map=d[key]||{}; if(clean) map[name]=clean; else delete map[name]; await chrome.storage.local.set({[key]:map});
}
async function resetType(type) { const key=type==='cape'?'currentCapes':'currentSkins'; const list=type==='cape'?CAPES:SKINS; const d=await chrome.storage.local.get([key]); const map=d[key]||{}; const ids=Object.keys(map).filter(n=>list.includes(n)).map(n=>ruleId(type,n)); if(ids.length) await chrome.declarativeNetRequest.updateDynamicRules({removeRuleIds:ids}); await chrome.storage.local.set({[key]:{}}); }
chrome.runtime.onInstalled.addListener(async()=>{ const d=await chrome.storage.local.get(['currentSkins','currentCapes']); if(!d.currentSkins) await chrome.storage.local.set({currentSkins:{}}); if(!d.currentCapes) await chrome.storage.local.set({currentCapes:{}}); });
chrome.runtime.onMessage.addListener((msg,sender,sendResponse)=>{ (async()=>{try{
 if(msg?.type==='getState'){const d=await chrome.storage.local.get(['currentSkins','currentCapes']);sendResponse({ok:true,currentSkins:d.currentSkins||{},currentCapes:d.currentCapes||{}});return;}
 if(msg?.type==='setSkin'||msg?.type==='setCape'){const type=msg.type==='setCape'?'cape':'skin';await setTexture(type,type==='cape'?msg.capeName:msg.skinName,msg.customUrl||'');sendResponse({ok:true});return;}
 if(msg?.type==='resetSkins'||msg?.type==='resetCapes'){await resetType(msg.type==='resetCapes'?'cape':'skin');sendResponse({ok:true});return;}
 if(msg?.type==='resetAll'){await resetType('skin');await resetType('cape');sendResponse({ok:true});return;}
 sendResponse({ok:false,error:'Unknown message'});
 }catch(e){sendResponse({ok:false,error:String(e?.message||e)});}})();return true;});
