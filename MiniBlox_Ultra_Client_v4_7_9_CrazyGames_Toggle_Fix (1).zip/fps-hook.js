(() => {
  if (window.__mbucMainFpsHook) return;
  window.__mbucMainFpsHook = true;
  const originalRAF = window.requestAnimationFrame;
  if (typeof originalRAF !== 'function') return;
  let frames = 0;
  let last = performance.now();
  function tick(now) {
    frames++;
    const elapsed = now - last;
    if (elapsed >= 1000) {
      const fps = Math.round(frames * 1000 / elapsed);
      window.postMessage({ type: 'MBUC_FPS_METRIC', fps }, '*');
      frames = 0;
      last = now;
    }
    originalRAF.call(window, tick);
  }
  originalRAF.call(window, tick);
})();
